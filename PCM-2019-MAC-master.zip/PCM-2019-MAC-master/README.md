# PCM-2019-MAC
Pro Cycling Manager 2019 on MAC ! HELP


Bonjour,

j'aimerais beaucoup jouer à Pro Cycling Manager 2019.
Étant un jeux réservé à Windows il est très compliqué de le trouver pour mac, même impossible.
J'ai donc téléchargé le jeux en .exe 
Problème je n'arrive pas à l'ouvrire avec Wine, j'ai déja réussi avec d'autre jeux.
Si quelqu'un à une idée...
Sachant que je ne souhaite pas télcharger d'OS de type BootCamp ou Parralels.

Merci ! 


---------------------------------
Hello,

I would love to play Pro Cycling Manager 2019.
Being a game reserved for Windows it is very complicated to find it for mac, even impossible.
So I downloaded the game in .exe
Problem I can not open it with Wine, I have already succeeded with other games.
If someone has an idea...
Knowing that I don't want to download BootCamp or Parralels OS.

Thank you !
